import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="flex-grow flex flex-col items-center justify-center text-white text-center p-4">
      <h1 className="text-5xl font-bold mb-4">Bem-vindo à Medida Certa</h1>
      <p className="text-xl mb-8">Sua calculadora de IMC com um toque de rosa!</p>
      <Link to="/imc" className="mt-6 px-6 py-3 bg-pink-600 rounded-lg hover:bg-pink-700 transition-colors text-lg font-semibold">
        Ir para a Calculadora
      </Link>
    </div>
  );
};

export default Home;