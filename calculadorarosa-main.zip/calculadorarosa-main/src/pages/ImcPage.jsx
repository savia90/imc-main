import React from 'react';
import { Link } from 'react-router-dom';
import CalculadoraImc from '../components/CalculadoraImc/CalculadoraImc';

const ImcPage = () => {
  return (
    <div className="w-full flex flex-col items-center">
      <CalculadoraImc />
      <Link to="/" className="mt-8 px-4 py-2 bg-pink-600 text-white rounded-lg hover:bg-pink-700 transition-colors">
        Voltar para a Home
      </Link>
    </div>
  );
};

export default ImcPage;