import React from 'react';
import { Link } from 'react-router-dom';

const NotFound = () => {
  return (
    <div className="flex-grow flex flex-col items-center justify-center text-white text-center p-4">
      <h1 className="text-6xl font-bold text-pink-400">404</h1>
      <p className="text-2xl mt-4">Página não encontrada</p>
      <p className="text-gray-400 mt-2">A página que você está procurando não existe.</p>
      <Link to="/" className="mt-6 px-4 py-2 bg-pink-600 rounded-lg hover:bg-pink-700 transition-colors">Voltar para a Home</Link>
    </div>
  );
};

export default NotFound;