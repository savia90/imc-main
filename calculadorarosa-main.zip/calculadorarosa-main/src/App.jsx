import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar/Navbar";
import Footer from "./components/Footer/Footer";
import Home from "./pages/Home";
import ImcPage from "./pages/ImcPage";
import NotFound from "./pages/NotFound";

function App() {
  return (
    <div className="min-h-screen bg-pink-950 flex flex-col">
      <Navbar />
      <main className="flex-grow container mx-auto p-4 flex">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/imc" element={<ImcPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;
