import React, { useState, useEffect } from "react";
import { FaWeight, FaRulerVertical, FaLanguage, FaChartBar } from "react-icons/fa";
import { MdCalculate } from "react-icons/md";
import { languageContent } from "./content.js";

const CalculadoraImc = () => {
  const [metric, setMetric] = useState("metric");
  const [language, setLanguage] = useState("PT-BR");
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [bmi, setBmi] = useState(null);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    // Animação de entrada do card
    setIsMounted(true);
  }, []);

  const content = languageContent[language];

  const calculateBmi = (e) => {
    e.preventDefault();

    if (
      !height ||
      !weight ||
      isNaN(parseFloat(height)) ||
      isNaN(parseFloat(weight))
    ) {
      alert("Por favor, insira valores válidos para altura e peso.");
      return;
    }

    let heightValue = parseFloat(height);
    let weightValue = parseFloat(weight);
    let calculatedBmi;

    if (metric === "metric") {
      calculatedBmi = (weightValue / (heightValue * heightValue)).toFixed(2);
    } else {
      const [feet, inches] = height.toString().split(".").map(parseFloat);
      const totalInches = feet * 12 + (inches || 0);

      calculatedBmi = (
        (703 * weightValue) /
        (totalInches * totalInches)
      ).toFixed(2);
    }

    setBmi(calculatedBmi);
  };

  const clearFields = () => {
    setHeight("");
    setWeight("");
    setBmi(null);
  };

  const handleInputChange = (value, field) => {
    let cleanedValue = value.replace(/[^0-9.]/g, "");
    const parts = cleanedValue.split(".");

    if (parts.length > 2) {
      cleanedValue = `${parts[0]}.${parts.slice(1).join("")}`;
    }

    if (
      field === "height" &&
      metric === "metric" &&
      cleanedValue.length === 2 &&
      !cleanedValue.includes(".")
    ) {
      cleanedValue = `${cleanedValue[0]}.${cleanedValue[1]}`;
    }

    if (
      field === "height" &&
      metric === "imperial" &&
      cleanedValue.length === 2 &&
      !cleanedValue.includes(".")
    ) {
      cleanedValue = `${cleanedValue[0]}.${cleanedValue[1]}`;
    }

    field === "height" ? setHeight(cleanedValue) : setWeight(cleanedValue);
  };

  return (
    <div className="flex items-center justify-center p-4 w-full">
      <div
        className={`w-full max-w-4xl bg-pink-900 shadow-2xl rounded-2xl p-8 transition-all duration-700 ease-out md:flex md:gap-8 ${
          isMounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
        }`}
      >
        {/* Coluna da Esquerda: Formulário */}
        <div className="md:w-1/2 space-y-6">
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-white">{content.title}</h1>
            <div className="flex items-center space-x-2 p-1 bg-pink-800 rounded-full">
              <FaLanguage className="text-pink-300 ml-2" />
              <button
                onClick={() => setLanguage("PT-BR")}
                className={`px-3 py-1 text-sm rounded-full transition ${
                  language === "PT-BR"
                    ? "bg-pink-600 text-white shadow"
                    : "text-pink-200"
                }`}
              >
                PT-BR
              </button>
              <button
                onClick={() => setLanguage("ENG")}
                className={`px-3 py-1 text-sm rounded-full transition ${
                  language === "ENG"
                    ? "bg-pink-600 text-white shadow"
                    : "text-pink-200"
                }`}
              >
                ENG
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => {
                setMetric("metric");
                clearFields();
              }}
              className={`p-4 rounded-lg text-center font-semibold transition-all duration-300 transform hover:-translate-y-1 ${
                metric === "metric"
                  ? "bg-pink-600 text-white shadow-md"
                  : "bg-pink-800 text-pink-200 hover:bg-pink-700"
              }`}
            >
              {content.metric}
            </button>
            <button
              onClick={() => {
                setMetric("imperial");
                clearFields();
              }}
              className={`p-4 rounded-lg text-center font-semibold transition-all duration-300 transform hover:-translate-y-1 ${
                metric === "imperial"
                  ? "bg-pink-600 text-white shadow-md"
                  : "bg-pink-800 text-pink-200 hover:bg-pink-700"
              }`}
            >
              {content.imperial}
            </button>
          </div>

          <form onSubmit={calculateBmi} className="space-y-4">
            <div>
              <label className="text-sm font-medium text-pink-200">
                {content.height}
              </label>
              <div className="relative mt-1">
                <FaRulerVertical className="absolute left-3 top-1/2 -translate-y-1/2 text-pink-300" />
                <input
                  type="text"
                  value={height}
                  onChange={(e) => handleInputChange(e.target.value, "height")}
                  placeholder={
                    metric === "metric"
                      ? content.heightPlaceholderMetric
                      : content.heightPlaceholderImperial
                  }
                  className="w-full pl-10 pr-12 py-3 bg-pink-800 text-white border border-pink-700 rounded-lg focus:ring-pink-500 focus:border-pink-500 transition-colors duration-300"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
                  {metric === "metric"
                    ? content.metricUnits.height
                    : content.imperialUnits.height}
                </span>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-pink-200">
                {content.weight}
              </label>
              <div className="relative mt-1">
                <FaWeight className="absolute left-3 top-1/2 -translate-y-1/2 text-pink-300" />
                <input
                  type="text"
                  value={weight}
                  onChange={(e) => handleInputChange(e.target.value, "weight")}
                  placeholder={
                    metric === "metric"
                      ? content.weightPlaceholderMetric
                      : content.weightPlaceholderImperial
                  }
                  className="w-full pl-10 pr-12 py-3 bg-pink-800 text-white border border-pink-700 rounded-lg focus:ring-pink-500 focus:border-pink-500 transition-colors duration-300"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
                  {metric === "metric"
                    ? content.metricUnits.weight
                    : content.imperialUnits.weight}
                </span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full flex justify-center items-center gap-2 bg-pink-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-pink-700 transition-all duration-300 shadow-md transform hover:-translate-y-1 active:translate-y-0"
            >
              <MdCalculate size={20} />
              {content.calculate}
            </button>
          </form>
        </div>

        {/* Coluna da Direita: Resultado */}
        <div className="md:w-1/2 flex flex-col justify-center items-center mt-8 md:mt-0">
          <div
            className={`w-full h-full flex flex-col justify-center items-center text-center bg-pink-800 p-6 rounded-lg border border-pink-700 transition-all duration-500 ease-in-out ${
              bmi ? "opacity-100" : "opacity-50"
            }`}
          >
            {bmi ? (
              <>
                <p className="text-lg text-pink-200">{content.yourBmi}:</p>
                <p className="text-6xl font-extrabold text-pink-300 my-4">{bmi}</p>
                <button
                  onClick={clearFields}
                  className="mt-4 text-sm text-pink-300 hover:text-pink-100 transition-colors"
                >
                  {content.clear}
                </button>
              </>
            ) : (
              <div className="text-center text-pink-300">
                <FaChartBar size={60} className="mx-auto mb-4" />
                <p className="text-xl">{content.resultTitle}</p>
                <p className="text-pink-400">{content.resultSubtitle}</p>
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};

export default CalculadoraImc;
