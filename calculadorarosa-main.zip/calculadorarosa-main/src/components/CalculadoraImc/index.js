import CalculadoraImc from "./CalculadoraImc";
export default CalculadoraImc;
