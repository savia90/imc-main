import React from "react";
import { FaFacebook, FaTwitter, FaInstagram } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-pink-900 text-white p-4 mt-auto">
      <div className="container mx-auto text-center">
        <div className="flex justify-center space-x-4">
          <a href="#" className="hover:text-pink-300 transition-colors">
            <FaFacebook size={24} />
          </a>
          <a href="#" className="hover:text-pink-300 transition-colors">
            <FaTwitter size={24} />
          </a>
          <a href="#" className="hover:text-pink-300 transition-colors">
            <FaInstagram size={24} />
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;